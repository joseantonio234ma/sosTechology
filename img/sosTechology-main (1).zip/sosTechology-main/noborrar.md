correo: sosTauxiliar@gmail.com
csñ: SosT0000

<div align="center" class="container">

    <div class="contorno row">

      <div class="boxcontainer">

        <div class="col-xs-6 col-md-12">
          <p class="alignpro">-Venta de Celulares Nuevos-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Celulares Usados-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Celulares de Exhibicion-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Retoma de Celulares-</p>
        </div>
  
      </div>
  
      <div class="boxcontainer">

        <div class="boxes2">  
          <p class="alignpro">-Venta de Accesorios Varios-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Estuches-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta y Instalacion de Vidrios Templados para Moviles-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Nano Ceramicos-</p>
        </div>
  
      </div>

      <div class="boxcontainer">

        <div class="boxes2">  
          <p class="alignpro">-Venta de SmartWatch-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Pulseras-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Parlantes-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Cargadores-</p>
        </div>
  
      </div>

      <div class="boxcontainer">

        <div class="boxes2">  
          <p class="alignpro">-Venta de Manos Libres-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Servicio Tecnico Especializado y Garantizado-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Cambio de Visor-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Cambio de Pantallas-</p>
        </div>
  
      </div>

      <div class="boxcontainer">

        <div class="boxes2">  
          <p class="alignpro">-Cambios de Batería-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Cambio de Tapas-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Venta de Hardware: Procesadores, Memorias RAM, Pantallas Moviles, Camaras, ETC-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Tramites con los Operadores de Telefonia Celular-</p>
        </div>
  
      </div>

      <div class="boxcontainer">

        <div class="boxes2">  
          <p class="alignpro">-Retiro de Reportes por no Registro-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Blindajes de Equipos Celulares-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Creditos-</p>
        </div>
  
        <div class="boxes2">
          <p class="alignpro">-Metodos de pago con Plan Separe-</p>
        </div>

      </div>

    </div>

  </div>